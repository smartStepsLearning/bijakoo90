const V='bijakoo-v2',F=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png','./apple-touch-icon.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(F)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!=V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!='GET')return;e.respondWith(fetch(r).then(x=>{if(x&&x.ok&&new URL(r.url).origin==location.origin){const y=x.clone();caches.open(V).then(z=>z.put(r,y))}return x}).catch(()=>caches.match(r).then(c=>c||caches.match('./index.html'))))});
